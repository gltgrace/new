# PersonalWebsitePart1
This is roughly how far we got after our first meeting!
